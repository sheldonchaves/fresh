#!/bin/bash

docker-compose -p dcm4chee down