#!/bin/bash

docker-compose -p dcm4chee start