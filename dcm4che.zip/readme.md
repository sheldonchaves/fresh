# Dasa Dcm4Che on Docker


#### Create docker compose
	docker-compose -p dcm4chee up -d
	create.sh

#### Start docker compose
	docker-compose -p dcm4chee start
	start.sh

#### Stop docker compose
	docker-compose -p dcm4chee stop
	stop.sh

#### Delete docker compose
	docker-compose -p dcm4chee down
	delete.sh




#### UI interface
	
	http://localhost:8080/dcm4chee-arc/ui2/

	//http://localhost:8080/dcm4chee-arc/aets


#### admin wildfly

	http://localhost:9990